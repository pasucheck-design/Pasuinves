#!/usr/bin/env python3
"""ดึงข้อมูลตลาด คำนวณ SMC แล้วเขียนไฟล์ docs/data.json
ใช้ไลบรารีมาตรฐานของ Python เท่านั้น ไม่ต้องติดตั้งอะไรเพิ่ม
"""
import csv
import datetime as dt
import io
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "docs", "data.json")
CONFIG = os.path.join(ROOT, "config.json")
UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0 Safari/537.36")
KEEP = 260  # จำนวนแท่งที่ส่งให้หน้าแอปต่อกรอบเวลา (EMA100 ต้องมีแท่งอุ่นเครื่อง)

# (id, ชื่อสั้น, ชื่อเต็ม, สัญลักษณ์ Yahoo Finance, ทศนิยม)
ASSETS = [
    ("set", "SET", "หุ้นไทย (ดัชนี SET)", "^SET.BK", 2),
    ("tfex", "TFEX", "TFEX (ใช้ดัชนี SET50 แทน)", "^SET50.BK", 2),
    ("gold", "ทองคำ", "ทองคำ (ฟิวเจอร์ส COMEX)", "GC=F", 2),
    ("ust", "US10Y", "ยิลด์พันธบัตรสหรัฐ 10 ปี", "^TNX", 3),
    ("btc", "BTC", "คริปโต (Bitcoin)", "BTC-USD", 0),
    ("thb", "USD/THB", "ค่าเงิน USD/THB", "THB=X", 2),
]

errors = []


def http_get(url, retries=3, timeout=30):
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 * (i + 1))
    raise last


def yahoo(symbol, interval, rng):
    url = ("https://query1.finance.yahoo.com/v8/finance/chart/%s?interval=%s&range=%s"
           "&includePrePost=false" % (urllib.parse.quote(symbol), interval, rng))
    j = json.loads(http_get(url))
    res = j["chart"]["result"][0]
    ts = res.get("timestamp") or []
    q = res["indicators"]["quote"][0]
    bars = []
    for i, t in enumerate(ts):
        o, h, l, c = q["open"][i], q["high"][i], q["low"][i], q["close"][i]
        if None in (o, h, l, c):
            continue
        bars.append({"t": t, "o": o, "h": h, "l": l, "c": c})
    return bars


def to_4h(bars):
    """รวมแท่ง 1 ชม. เป็นแท่ง 4 ชม. (แบ่งตามเวลา UTC ทุก 4 ชม.)"""
    out, cur = [], None
    for b in bars:
        k = b["t"] // 14400
        if cur is not None and cur["k"] == k:
            cur["h"] = max(cur["h"], b["h"])
            cur["l"] = min(cur["l"], b["l"])
            cur["c"] = b["c"]
        else:
            if cur is not None:
                out.append(cur)
            cur = {"k": k, "t": b["t"], "o": b["o"], "h": b["h"], "l": b["l"], "c": b["c"]}
    if cur is not None:
        out.append(cur)
    return out


def smc(bars, dec, k=3):
    """SMC แบบง่าย
    - หาจุดกลับตัว (pivot) ด้วยหน้าต่าง k แท่งซ้าย/ขวา
    - ราคาปิดทะลุจุดสูงล่าสุด = เบรกขึ้น, ทะลุจุดต่ำล่าสุด = เบรกลง
    - เบรกตามทิศเดิม = BOS, เบรกสวนทิศ = CHoCH
    - Order Block = แท่งสวนทิศล่าสุดก่อนการเบรก
    - บอกตำแหน่งพรีเมียม/ดิสเคานต์ของกรอบล่าสุด (ไม่มีผลต่อคะแนน)
    """
    bars = bars[-400:]
    n = len(bars)
    if n < 2 * k + 10:
        return {"b": 0, "t": "ข้อมูลไม่พอ"}
    sh = sl = None  # pivot ที่ยังไม่ถูกเบรก
    rh = rl = None  # กรอบล่าสุด (ไม่ล้างเมื่อเบรก)
    bias, kind, ob = 0, "", None
    for i in range(n):
        p = i - k
        if p >= k:
            win = bars[p - k:p + k + 1]
            if bars[p]["h"] >= max(x["h"] for x in win):
                sh = rh = (p, bars[p]["h"])
            if bars[p]["l"] <= min(x["l"] for x in win):
                sl = rl = (p, bars[p]["l"])
        c = bars[i]["c"]
        if sh is not None and c > sh[1]:
            kind = "CHoCH" if bias == -1 else "BOS"
            bias = 1
            start = sl[0] if sl is not None else max(0, i - 30)
            ob = None
            for j in range(i - 1, start - 1, -1):
                if bars[j]["c"] < bars[j]["o"]:
                    ob = (bars[j]["l"], bars[j]["h"])
                    break
            sh = None
        elif sl is not None and c < sl[1]:
            kind = "CHoCH" if bias == 1 else "BOS"
            bias = -1
            start = sh[0] if sh is not None else max(0, i - 30)
            ob = None
            for j in range(i - 1, start - 1, -1):
                if bars[j]["c"] > bars[j]["o"]:
                    ob = (bars[j]["l"], bars[j]["h"])
                    break
            sl = None
    if bias == 0:
        return {"b": 0, "t": "ยังไม่เกิดการเบรกโครงสร้างที่ชัดเจน"}
    c = bars[-1]["c"]
    parts = ["%s %s" % (kind, "ขึ้น" if bias == 1 else "ลง")]
    if rh and rl and rh[1] > rl[1]:
        pct = (c - rl[1]) / (rh[1] - rl[1]) * 100
        if pct > 100 or pct < 0:
            parts.append("ราคาอยู่นอกกรอบเดิม")
        else:
            parts.append("ราคาอยู่โซน%s (%.0f%%)" % ("พรีเมียม" if pct > 50 else "ดิสเคานต์", pct))
    if ob:
        s = "%s OB %s–%s" % ("Demand" if bias == 1 else "Supply",
                             format(ob[0], ",.%df" % dec), format(ob[1], ",.%df" % dec))
        if ob[0] <= c <= ob[1]:
            s += " (ราคาอยู่ในโซน)"
        parts.append(s)
    return {"b": bias, "t": " · ".join(parts)}


def build_asset(a):
    id_, short, name, sym, dec = a
    b4 = to_4h(yahoo(sym, "1h", "730d"))
    d1 = yahoo(sym, "1d", "3y")
    w1 = yahoo(sym, "1wk", "10y")
    tfs = []
    for key, bars in (("4h", b4), ("1d", d1), ("1w", w1)):
        if len(bars) < 120:
            raise ValueError("%s กรอบ %s มีข้อมูลแค่ %d แท่ง" % (sym, key, len(bars)))
        tfs.append({"k": key,
                    "closes": [round(x["c"], 6) for x in bars[-KEEP:]],
                    "smc": smc(bars, dec)})
    return {"id": id_, "short": short, "name": name, "dec": dec, "symbol": sym, "tf": tfs}


def fred(series):
    raw = http_get("https://fred.stlouisfed.org/graph/fredgraph.csv?id=%s" % series).decode("utf-8")
    out = []
    for r in list(csv.reader(io.StringIO(raw)))[1:]:
        try:
            out.append((r[0], float(r[1])))
        except (ValueError, IndexError):
            pass
    return out


def yahoo_stat(sym, days=5):
    bars = yahoo(sym, "1d", "1mo")
    last = bars[-1]["c"]
    ref = bars[-1 - days]["c"] if len(bars) > days else bars[0]["c"]
    return last, ref


def macro(cfg):
    items = []

    def add(label, fn):
        try:
            items.append(fn())
        except Exception as e:  # noqa: BLE001
            errors.append("%s: %s" % (label, e))

    def m_fed():
        s = fred("DFF")
        v = s[-1][1]
        prev = s[-31][1] if len(s) > 31 else s[0][1]
        d = v - prev
        return {"k": "ดอกเบี้ย Fed (Fed Funds)", "v": "%.2f%%" % v,
                "d": "ไม่เปลี่ยนใน 30 วัน" if abs(d) < 0.005 else "%+.2f จุดใน 30 วัน" % d}

    def m_cpi():
        s = fred("CPIAUCSL")
        n = len(s) - 1
        yoy = (s[n][1] / s[n - 12][1] - 1) * 100
        prev = (s[n - 1][1] / s[n - 13][1] - 1) * 100
        return {"k": "เงินเฟ้อสหรัฐ (CPI รายปี)", "v": "%.1f%%" % yoy,
                "d": "ก่อนหน้า %.1f%% · ข้อมูลเดือน %s" % (prev, s[n][0][:7])}

    def m_dxy():
        last, ref = yahoo_stat("DX-Y.NYB")
        return {"k": "ดัชนีดอลลาร์ (DXY)", "v": "%.2f" % last,
                "d": "%+.1f%% ใน 5 วัน" % ((last / ref - 1) * 100)}

    def m_ust():
        last, ref = yahoo_stat("^TNX")
        return {"k": "ยิลด์สหรัฐ 10 ปี", "v": "%.2f%%" % last,
                "d": "%+.0f bps ใน 5 วัน" % ((last - ref) * 100)}

    def m_thb():
        last, ref = yahoo_stat("THB=X")
        return {"k": "ค่าเงินบาท (USD/THB)", "v": "%.2f" % last,
                "d": "%+.1f%% ใน 5 วัน" % ((last / ref - 1) * 100)}

    def m_vix():
        last, ref = yahoo_stat("^VIX")
        return {"k": "VIX (ความผันผวนหุ้นสหรัฐ)", "v": "%.1f" % last,
                "d": "%+.1f%% ใน 5 วัน" % ((last / ref - 1) * 100)}

    def m_oil():
        last, ref = yahoo_stat("CL=F")
        return {"k": "น้ำมันดิบ WTI", "v": "$%.2f" % last,
                "d": "%+.1f%% ใน 5 วัน" % ((last / ref - 1) * 100)}

    add("Fed", m_fed)
    if cfg.get("bot_rate"):
        items.append({"k": "ดอกเบี้ย ธปท.", "v": str(cfg["bot_rate"]), "d": str(cfg.get("bot_note", ""))})
    add("CPI", m_cpi)
    add("DXY", m_dxy)
    add("US10Y", m_ust)
    add("USD/THB", m_thb)
    add("VIX", m_vix)
    add("WTI", m_oil)
    return items


def fear_greed():
    try:
        d = json.loads(http_get("https://api.alternative.me/fng/?limit=1"))["data"][0]
        return {"v": int(d["value"]), "src": "Fear & Greed Index (คริปโต, alternative.me)"}
    except Exception as e:  # noqa: BLE001
        errors.append("Fear & Greed: %s" % e)
        return None


def news():
    topics = [
        ("Fed", "Federal Reserve interest rates"),
        ("สงคราม", "war ceasefire conflict"),
        ("น้ำมัน", "oil prices OPEC"),
        ("สหรัฐ–จีน", "US China trade tariffs politics"),
    ]
    out = []
    for tag, q in topics:
        try:
            url = "https://news.google.com/rss/search?" + urllib.parse.urlencode(
                {"q": q + " when:1d", "hl": "en-US", "gl": "US", "ceid": "US:en"})
            root = ET.fromstring(http_get(url))
            got = 0
            for it in root.iter("item"):
                title = (it.findtext("title") or "").strip()
                link = (it.findtext("link") or "").strip()
                if title and link:
                    out.append({"t": tag, "x": title, "u": link})
                    got += 1
                if got >= 2:
                    break
        except Exception as e:  # noqa: BLE001
            errors.append("ข่าว %s: %s" % (tag, e))
    return out


def main():
    try:
        with open(CONFIG, encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:  # noqa: BLE001
        cfg = {}
    assets = []
    for a in ASSETS:
        try:
            assets.append(build_asset(a))
            print("ok  ", a[3])
        except Exception as e:  # noqa: BLE001
            errors.append("%s: %s" % (a[1], e))
            print("FAIL", a[3], e, file=sys.stderr)
    if len(assets) < 3:
        print("ดึงข้อมูลสินทรัพย์ได้น้อยกว่า 3 รายการ ยกเลิกการอัปเดต", file=sys.stderr)
        for e in errors:
            print(" -", e, file=sys.stderr)
        sys.exit(1)
    payload = {
        "updated": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "assets": assets,
        "macro": macro(cfg),
        "fg": fear_greed(),
        "news": news(),
        "errors": errors,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, separators=(",", ":"))
    print("เขียน %s แล้ว (%d สินทรัพย์, %d ข้อผิดพลาด)" % (OUT, len(assets), len(errors)))


if __name__ == "__main__":
    main()
